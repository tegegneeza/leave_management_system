var express = require('express');
var router = express.Router();
var api = require('../api/api');
var uuid = require("uuid");

/* GET home page. */
router.get('/', function (req, res, next) {
    var employee = req.session.email;
    if (employee) {
        return api.loadEmployee(employee).then(function (employee) {
            if (employee) {
                console.log("Gotchsa");
                var leaves = employee.emp_leaves, context = {};

                res.render('employeeHome', {title: 'Leave Management System', name:employee.emp_name ,obj: employee.emp_leaves});
            }
        });
    }
    else {
        res.redirect('/');
    }

});


router.post('/', function (req, res, next) {
    var employee = req.session.email, promise;
    return api.loadEmployee(employee).then(function (employee) {
        if (employee) {

            console.log("Gotchsa");
            employee.emp_leaves.push(createLeaveObject(req));
            promise = employee.save();
            return promise;
        }
    }).then(function (employee) {
        console.log("leave applied successfull");
        res.redirect('/employeeHome');
    });
});


/*var createLeaveObject = function (req) {
    var leaveObj = {}, body = req.body;
    leaveObj.leaveId = uuid.v4();
    leaveObj.startDate = body.startDate;
    leaveObj.endDate = body.endDate;
    leaveObj.status = "pending";
    leaveObj.reason = "";
    return leaveObj;
};*/

var createLeaveObject = function (req) {
    var leaveObj = {}, body = req.body;
    leaveObj.leaveId = uuid.v4();
    leaveObj.startDate = body.startDate;
    leaveObj.endDate = body.endDate;
    leaveObj.status = "pending";
    leaveObj.reason = "";
    leaveObj.leaveType = body.leaveType; // new field for type of leave
    switch(leaveObj.leaveType) {
        case 'sick':
            leaveObj.allowedDays = 20;
            break;
        case 'vacation':
            leaveObj.allowedDays = 15;
            break;
        case 'incident':
            leaveObj.allowedDays = 5;
            break;
        default:
            leaveObj.allowedDays = 0;
    }
    return leaveObj;
};


module.exports = router;
