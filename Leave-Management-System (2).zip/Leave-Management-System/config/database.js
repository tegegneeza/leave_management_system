(function(){

    var dbObj = {};
    //dbObj.url = 'mongodb://test:test@lms.1nc7f.mongodb.net/lms';
    dbObj.url = 'mongodb+srv://test:test@lms.1nc7f.mongodb.net/lms';

    module.exports = dbObj;
})();